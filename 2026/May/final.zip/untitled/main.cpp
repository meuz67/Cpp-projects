#include <iostream>
#include <cstring>
#include <windows.h>
class Human {
private:
    char* name;
    int age;
public:
    Human() : name(nullptr), age(0) {}
    Human(const char* n, int a) : age(a) {
        name = new char[strlen(n) + 1];
        strcpy(name, n);
    }
    Human(const Human& other) : age(other.age) {
        name = new char[strlen(other.name) + 1];
        strcpy(name, other.name);
    }
    ~Human() {
        delete[] name;
    }
    void print() const {
        std::cout << "Мешканець: " << (name ? name : "Невідомо") << ", Вік: " << age << std::endl;
    }
};
class Apartment {
private:
    Human* residents;
    int count;
    int number;
public:
    Apartment() : residents(nullptr), count(0), number(0) {}
    Apartment(int num, int maxResidents) : number(num), count(0) {
        residents = new Human[maxResidents];
    }
    Apartment(const Apartment& other) : count(other.count), number(other.number) {
        residents = new Human[10];
        for (int i = 0; i < count; ++i) {
            residents[i] = other.residents[i];
        }
    }
    ~Apartment() {
        delete[] residents;
    }
    void addResident(const Human& h) {
        residents[count++] = h;
    }
    void print() const {
        std::cout << "Квартира №" << number << ":" << std::endl;
        for (int i = 0; i < count; ++i) {
            std::cout << "  ";
            residents[i].print();
        }
    }
};
class House {
private:
    Apartment* apartments;
    int count;
    char* address;
public:
    House(const char* addr, int maxApartments) : count(0) {
        address = new char[strlen(addr) + 1];
        strcpy(address, addr);
        apartments = new Apartment[maxApartments];
    }
    House(const House& other) : count(other.count) {
        address = new char[strlen(other.address) + 1];
        strcpy(address, other.address);
        apartments = new Apartment[10];
        for (int i = 0; i < count; ++i) {
            apartments[i] = other.apartments[i];
        }
    }
    ~House() {
        delete[] address;
        delete[] apartments;
    }
    void addApartment(const Apartment& a) {
        apartments[count++] = a;
    }
    void print() const {
        std::cout << "Будинок: " << address << std::endl;
        for (int i = 0; i < count; ++i) {
            apartments[i].print();
        }
    }
};
int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    Human h1("Іван", 30);
    Human h2("Марія", 25);
    Apartment apt1(101, 5);
    apt1.addResident(h1);
    apt1.addResident(h2);
    House myHouse("Центральна 1", 10);
    myHouse.addApartment(apt1);
    myHouse.print();
    std::cout << "\n--- Копія будинку ---" << std::endl;
    House duplicate = myHouse;
    duplicate.print();
    return 0;
}